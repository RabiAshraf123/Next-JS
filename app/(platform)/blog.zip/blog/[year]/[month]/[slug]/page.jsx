async function getSlug(id) {
  const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`);

  if (!res.ok) throw new Error("Post not found");

  return res.json();
}

export default async function Blogpost({ params }) {
  const post = await getSlug(params.slug);

  return <h1>{post.title}</h1>;
}